\c pokedabe
DELETE FROM Region;
INSERT INTO Region VALUES('Kanto','FireRed /Green Leaf','./Kanto.jpg');
INSERT INTO Region VALUES('Hoenn','Ruby / Emerald / Sapphire','./Hoenn.jpg');
INSERT INTO Region VALUES('Johto','Gold / Silver / Crystal','./Johto.jpg');
INSERT INTO Region VALUES('Sinnoh','Diamond / Pearl / Platinum','./Sinnoh.jpg');
INSERT INTO Region VALUES('Unova','FireRed /Green Leaf','./Unova.jpg');
INSERT INTO Region VALUES('Kalos','X / Y','./Kalos.jpg');
INSERT INTO Region VALUES('Alola','Sun / Moon','./Alola.jpg');
