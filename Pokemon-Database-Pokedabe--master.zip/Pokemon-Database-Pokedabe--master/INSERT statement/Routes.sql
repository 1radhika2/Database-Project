
\c pokedabe
DELETE FROM Routes;
INSERT INTO Routes VALUES (1,'Pallet','Viridian','./1.jpg');
INSERT INTO Routes VALUES (2,'Viridian','Pewter','./2.jpg');
INSERT INTO Routes VALUES (3,'Pewter','Route 4','./3.jpg');
INSERT INTO Routes VALUES (4,'Route 3','Cerulean','./4.jpg');
INSERT INTO Routes VALUES (5,'Cerulean','Saffron','./5.jpg');
INSERT INTO Routes VALUES (6,'Saffron','Vermilion','./6.jpg');
INSERT INTO Routes VALUES (7,'Saffron','Celadon','./7.jpg');
INSERT INTO Routes VALUES (8,'Saffron','Lavender','./8.jpg');
INSERT INTO Routes VALUES (9,'Cerulean','Route 10','./9.jpg');
INSERT INTO Routes VALUES (10,'Route 9','Lavender','./10.jpg');
INSERT INTO Routes VALUES (11,'Vermilion','Route 12','./11.jpg');
INSERT INTO Routes VALUES (12,'Lavender','Route 13','./12.jpg');
INSERT INTO Routes VALUES (13,'Route 12','Route 14','./13.jpg');
INSERT INTO Routes VALUES (14,'Route 13','Route 15','./14.jpg');
INSERT INTO Routes VALUES (15,'Route 14','Fuchsia','./15.jpg');
INSERT INTO Routes VALUES (16,'Celadon','Route 17','./16.jpg');
INSERT INTO Routes VALUES (17,'Route 16','Route 18','./17.jpg');
INSERT INTO Routes VALUES (18,'Route 17','Fuchsia','./18.jpg');
INSERT INTO Routes VALUES (19,'Fuchsia','Route 20','./19.jpg');
INSERT INTO Routes VALUES (20,'Route 19','Cinnabar Islands','./20.jpg');
INSERT INTO Routes VALUES (21,'Cinnabar Islands','Pallet','./21.jpg');
INSERT INTO Routes VALUES (22,'Viridian','Route 23','./22.jpg');
INSERT INTO Routes VALUES (23,'Route 22','Indigo Plateau','./23.jpg');
INSERT INTO Routes VALUES (24,'Cerulean','Route 25','./24.jpg');
INSERT INTO Routes VALUES (25,'Route 25',null,'./25.jpg');